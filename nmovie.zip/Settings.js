module.exports={
	cookieSecret:'mysecretdo',
	db:'mysecret',
	host:'localhost',
}